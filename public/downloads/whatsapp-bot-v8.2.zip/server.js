/**
 * Goloso — Bot local de WhatsApp.
 *
 * Corre en el PC de cada sede. Usa Baileys (WhatsApp Web protocol) para
 * conectarse al número de la sede escaneando un QR una sola vez.
 * Toda la lógica de "qué responder" vive en el POS: este bot solo:
 *   1. Reporta estado al POS cada 30s (heartbeat + QR cuando aplique).
 *   2. Cuando llega un mensaje entrante, lo envía al POS y responde con
 *      lo que el POS le indique.
 *
 * Config: `config.json` con { token, apiUrl }. Se crea con `setup.js`.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import http from "node:http";
import QRCode from "qrcode";
import pino from "pino";
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  downloadMediaMessage,
} from "@whiskeysockets/baileys";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, "config.json");
const AUTH_DIR = path.join(__dirname, "auth_state");
const inferredBranchPort = /sede\s*2|sede2|parque/i.test(__dirname) ? 8791 : 8790;
const REQUESTED_LOCAL_PORT = Number(process.env.PORT) || inferredBranchPort;
const LOCAL_PORT_SCAN_LIMIT = 20;
const HEARTBEAT_MS = 10_000;
const OUTBOUND_POLL_MS = 5_000;
const REPLY_DELAY_MIN = 2000;
const REPLY_DELAY_MAX = 5000;
const OUTBOUND_DELAY_MIN = 1500;
const OUTBOUND_DELAY_MAX = 3500;
const VERSION_FETCH_TIMEOUT_MS = 7_000;
const AI_MAX_AUDIO_BYTES = 1_500_000; // ~1.5 MB → notas de voz cortas
const BOT_VERSION = "8.2.0";

const logger = pino({ level: "info" }, pino.destination({ dest: path.join(__dirname, "bot.log"), sync: false }));
let activeLocalPort = REQUESTED_LOCAL_PORT;

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    console.error("\nNo hay config.json. Ejecuta primero: node setup.js\n");
    process.exit(1);
  }
  const raw = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));
  if (!raw.token || !raw.apiUrl) {
    console.error("config.json inválido: faltan token o apiUrl.");
    process.exit(1);
  }
  return raw;
}

const config = loadConfig();

let state = {
  status: "connecting",     // connecting | qr | connected | disconnected | error
  qr: null,                  // string cuando status === "qr"
  qrDataUrl: null,           // dataURL para servir en localhost
  phone: null,
  lastError: null,
  lastPushError: null,
  lastPushAt: null,
  lastOutboundPollAt: null,
  lastOutboundCount: 0,
  lastOutboundError: null,
  detail: "Iniciando conexión con WhatsApp...",
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function pushStatus() {
  try {
    const body = {
      action: "status",
      token: config.token,
      status: state.status,
      qr: state.qr,
      phone: state.phone,
      version: BOT_VERSION,
    };
    const res = await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const txt = await res.text();
      state.lastPushError = `POS respondió ${res.status}: ${txt.slice(0, 250)}`;
      logger.warn({ status: res.status, body: txt }, "status push failed");
      return;
    }
    const txt = await res.text();
    let data = null;
    try { data = txt ? JSON.parse(txt) : null; } catch { data = { raw: txt.slice(0, 250) }; }
    if (data?.error) {
      state.lastPushError = `POS rechazó estado: ${data.error}`;
      logger.warn({ body: data }, "status push rejected");
      return;
    }
    state.lastPushError = null;
    state.lastPushAt = Date.now();
    // Ejecutar comando remoto si el POS lo pidió (unlink | reconnect).
    if (data?.pending_command) {
      const cmd = String(data.pending_command);
      logger.info({ cmd }, "remote command received");
      executeRemoteCommand(cmd).catch((e) => logger.warn({ err: String(e) }, "remote command failed"));
    }
  } catch (e) {
    state.lastPushError = String(e);
    logger.warn({ err: String(e) }, "status push error");
  }
}

async function ackCommand(cmd) {
  try {
    await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "command_ack", token: config.token, command: cmd }),
    });
  } catch (e) {
    logger.warn({ err: String(e) }, "ack command failed");
  }
}

function rmAuthDir() {
  try {
    if (fs.existsSync(AUTH_DIR)) {
      fs.rmSync(AUTH_DIR, { recursive: true, force: true });
      logger.info("auth_state removed");
    }
  } catch (e) {
    logger.warn({ err: String(e) }, "could not remove auth_state");
  }
}

let commandInFlight = false;
async function executeRemoteCommand(cmd) {
  if (commandInFlight) return;
  commandInFlight = true;
  try {
    if (cmd === "unlink") {
      state.detail = "Desvinculando dispositivo por solicitud del POS...";
      if (currentSock) {
        try { await currentSock.logout(); } catch (e) { logger.warn({ err: String(e) }, "logout error"); }
        try { currentSock.ws?.close?.(); } catch { /* noop */ }
        currentSock = null;
      }
      rmAuthDir();
      await ackCommand("unlink");
      state.status = "connecting";
      state.qr = null;
      state.qrDataUrl = null;
      state.phone = null;
      state.detail = "Sesión eliminada. Generando nuevo QR...";
      await pushStatus();
      setTimeout(() => startSocket().catch((e) => logger.error(e)), 1500);
      return;
    }
    if (cmd === "reconnect") {
      state.detail = "Reconectando por solicitud del POS...";
      if (currentSock) {
        try { currentSock.ws?.close?.(); } catch { /* noop */ }
        currentSock = null;
      }
      await ackCommand("reconnect");
      state.status = "connecting";
      await pushStatus();
      setTimeout(() => startSocket().catch((e) => logger.error(e)), 1500);
      return;
    }
  } finally {
    commandInFlight = false;
  }
}

async function handleIncoming(from, body) {
  try {
    const res = await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "incoming", token: config.token, from, message: body }),
    });
    if (!res.ok) {
      logger.warn({ status: res.status }, "incoming push failed");
      return null;
    }
    const data = await res.json();
    return data.reply || null;
  } catch (e) {
    logger.warn({ err: String(e) }, "incoming error");
    return null;
  }
}

async function requestAiReply(from, { text, audioB64, audioMime }) {
  try {
    const res = await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "ai_reply",
        token: config.token,
        from,
        text: text || "",
        audio_b64: audioB64 || "",
        audio_mime: audioMime || "",
      }),
    });
    if (!res.ok) {
      logger.warn({ status: res.status }, "ai_reply http fail");
      return null;
    }
    const data = await res.json();
    if (data.error) logger.info({ err: data.error }, "ai_reply skipped");
    return data.reply || null;
  } catch (e) {
    logger.warn({ err: String(e) }, "ai_reply error");
    return null;
  }
}

function humanDelay() {
  return Math.floor(REPLY_DELAY_MIN + Math.random() * (REPLY_DELAY_MAX - REPLY_DELAY_MIN));
}

function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} tardó más de ${Math.round(ms / 1000)}s`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

async function getSafeBaileysVersion() {
  try {
    const { version } = await withTimeout(fetchLatestBaileysVersion(), VERSION_FETCH_TIMEOUT_MS, "La consulta de versión de WhatsApp");
    logger.info({ version }, "using latest WhatsApp Web version");
    return version;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.warn({ err: message }, "could not fetch latest WhatsApp Web version; using bundled Baileys version");
    state.lastError = `${message}. Se continúa con la versión incluida en el bot.`;
    return undefined;
  }
}

let currentSock = null;
let outboundInFlight = false;

function normalizeOutboundPhone(raw) {
  let digits = String(raw || "").replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.length === 10) digits = `57${digits}`;
  return digits;
}

async function reportOutboundPoll(status, count = 0, error = null) {
  try {
    await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "poll_status",
        token: config.token,
        version: BOT_VERSION,
        pollStatus: status,
        pollCount: count,
        error,
      }),
    });
  } catch (e) {
    logger.warn({ err: String(e) }, "poll status report failed");
  }
}

async function pollOutbound() {
  if (!currentSock || state.status !== "connected") return;
  if (outboundInFlight) return;
  outboundInFlight = true;
  try {
    const res = await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "pending", token: config.token, version: BOT_VERSION }),
    });
    if (!res.ok) {
      const txt = await res.text();
      const message = `pending respondió ${res.status}: ${txt.slice(0, 250)}`;
      state.lastOutboundError = message;
      await reportOutboundPoll("error", 0, message);
      return;
    }
    const data = await res.json();
    if (data?.error) {
      const message = `pending rechazado: ${data.error}`;
      state.lastOutboundError = message;
      await reportOutboundPoll("error", 0, message);
      return;
    }
    const pending = Array.isArray(data?.pending) ? data.pending : [];
    state.lastOutboundPollAt = Date.now();
    state.lastOutboundCount = pending.length;
    state.lastOutboundError = null;
    await reportOutboundPoll("ok", pending.length, null);
    if (pending.length === 0) return;
    const sent = [];
    const failed = [];
    let lastErr = null;
    for (const item of pending) {
      const to = normalizeOutboundPhone(item.to);
      if (!to || !item.body) { failed.push(item.id); continue; }
      const jid = `${to}@s.whatsapp.net`;
      try {
        const exists = await currentSock.onWhatsApp(jid).catch(() => null);
        if (Array.isArray(exists) && exists.length > 0 && exists[0]?.exists === false) {
          throw new Error(`El número ${to} no aparece activo en WhatsApp`);
        }
        await currentSock.sendMessage(jid, { text: String(item.body) });
        sent.push(item.id);
        logger.info({ to }, "outbound sent");
        await new Promise((r) => setTimeout(r, OUTBOUND_DELAY_MIN + Math.random() * (OUTBOUND_DELAY_MAX - OUTBOUND_DELAY_MIN)));
      } catch (e) {
        failed.push(item.id);
        lastErr = String(e);
        logger.warn({ err: lastErr, to }, "outbound send failed");
      }
    }
    state.lastOutboundError = lastErr;
    await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "ack", token: config.token, sent, failed, error: lastErr, version: BOT_VERSION }),
    });
  } catch (e) {
    const message = String(e);
    state.lastOutboundError = message;
    await reportOutboundPoll("error", 0, message);
    logger.warn({ err: message }, "poll outbound error");
  } finally {
    outboundInFlight = false;
  }
}

async function startSocket() {
  state.status = "connecting";
  state.detail = "Preparando sesión de WhatsApp...";
  console.log("\nConectando con WhatsApp. El QR puede tardar unos segundos...\n");
  const { state: authState, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const version = await getSafeBaileysVersion();
  state.detail = "Esperando respuesta de WhatsApp para generar el QR...";
  const socketConfig = {
    auth: authState,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    browser: ["Goloso Bot", "Chrome", "1.0"],
    connectTimeoutMs: 30_000,
    defaultQueryTimeoutMs: 60_000,
  };
  if (version) socketConfig.version = version;
  const sock = makeWASocket(socketConfig);

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      state.status = "qr";
      state.qr = qr;
      state.qrDataUrl = await QRCode.toDataURL(qr, { width: 320, margin: 1 });
      state.detail = "QR generado. Escanéalo con WhatsApp Business.";
      logger.info("QR generated");
      console.log("\n✅ QR generado. Escanéalo desde WhatsApp Business.\n");
      try {
        console.log(await QRCode.toString(qr, { type: "terminal", small: true }));
      } catch {
        console.log(`Abre http://localhost:${activeLocalPort} para ver el QR.`);
      }
      pushStatus();
    }
    if (connection === "open") {
      state.status = "connected";
      state.qr = null;
      state.qrDataUrl = null;
      state.phone = sock.user?.id?.split(":")[0]?.split("@")[0] ?? null;
      state.detail = "Conectado correctamente.";
      logger.info({ phone: state.phone }, "connected");
      console.log(`\n✅ WhatsApp conectado${state.phone ? `: +${state.phone}` : ""}.\n`);
      pushStatus();
      setTimeout(() => pollOutbound().catch((e) => logger.warn({ err: String(e) }, "initial outbound poll failed")), 1200);
    } else if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = code !== DisconnectReason.loggedOut;
      logger.warn({ code, shouldReconnect }, "connection closed");
      state.status = "disconnected";
      state.qr = null;
      state.qrDataUrl = null;
      state.detail = shouldReconnect ? "Conexión cerrada. Reintentando automáticamente..." : "Sesión cerrada desde WhatsApp. Borra auth_state y vuelve a instalar para generar un QR nuevo.";
      pushStatus();
      if (shouldReconnect) setTimeout(() => startSocket().catch((e) => logger.error(e)), 5000);
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      const jid = msg.key.remoteJid || "";
      // Ignorar grupos, estados/historias, broadcasts y newsletters de WhatsApp.
      if (jid.endsWith("@g.us")) continue;
      if (jid.endsWith("@broadcast")) continue;
      if (jid.endsWith("@newsletter")) continue;
      if (jid.startsWith("status@")) continue;
      const text =
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        msg.message.videoMessage?.caption ||
        "";
      const audioNode = msg.message.audioMessage;
      const from = jid.split("@")[0];
      // Solo procesar mensajes de números reales (JID de usuario `@s.whatsapp.net`).
      if (!from || !/^\d{6,}$/.test(from)) continue;
      logger.info({ from, textLen: text.length, hasAudio: !!audioNode }, "incoming");

      // 1) Respuesta fija del POS (bienvenida, menú, fuera de horario…)
      let reply = null;
      if (text) reply = await handleIncoming(from, text);

      // 2) Fallback IA: si no hubo respuesta fija Y hay texto o nota de voz,
      //    pedimos al backend un reply generado (respeta sandbox/límite/enabled).
      if (!reply && (text || audioNode)) {
        let audioB64 = "";
        let audioMime = "";
        if (audioNode) {
          try {
            const buf = await downloadMediaMessage(msg, "buffer", {}, { logger, reuploadRequest: sock.updateMediaMessage });
            if (buf && buf.length <= AI_MAX_AUDIO_BYTES) {
              audioB64 = buf.toString("base64");
              audioMime = audioNode.mimetype || "audio/ogg";
            } else {
              logger.warn({ from, size: buf?.length }, "audio too large, skipping");
            }
          } catch (e) {
            logger.warn({ err: String(e) }, "audio download failed");
          }
        }
        try {
          const aiRes = await fetch(`${config.apiUrl}/api/public/whatsapp-bot`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "ai_reply",
              token: config.token,
              from,
              text: text || "",
              audio_b64: audioB64,
              audio_mime: audioMime,
            }),
          });
          if (aiRes.ok) {
            const aiData = await aiRes.json();
            if (aiData && aiData.reply) reply = String(aiData.reply);
            else if (aiData && aiData.error) logger.info({ err: aiData.error }, "ai_reply skipped");
          } else {
            logger.warn({ status: aiRes.status }, "ai_reply http fail");
          }
        } catch (e) {
          logger.warn({ err: String(e) }, "ai_reply error");
        }
      }

      if (reply) {
        await new Promise((r) => setTimeout(r, humanDelay()));
        try {
          await sock.sendMessage(msg.key.remoteJid, { text: reply });
          logger.info({ from }, "replied");
        } catch (e) {
          logger.warn({ err: String(e) }, "reply send failed");
        }
      }
    }
  });

  currentSock = sock;
  return sock;
}

function startLocalUI() {
  const server = http.createServer((req, res) => {
    if (req.url === "/" || req.url?.startsWith("/?")) {
      const statusColor = state.status === "connected" ? "#059669" : state.status === "qr" ? "#f59e0b" : "#dc2626";
      const html = `<!doctype html><html><head><meta charset="utf-8"><title>Goloso Bot</title>
<meta http-equiv="refresh" content="5">
<style>body{font-family:system-ui,-apple-system,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;margin:0;display:grid;place-items:center;padding:2rem}
.card{background:#1e293b;border-radius:16px;padding:2rem;max-width:460px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.4);text-align:center}
h1{margin:0 0 .5rem;font-size:1.5rem}
.status{display:inline-flex;align-items:center;gap:.5rem;padding:.5rem 1rem;border-radius:999px;background:${statusColor};color:white;font-weight:600;margin:.75rem 0}
.phone{color:#94a3b8;font-size:.875rem}
img{max-width:100%;background:white;padding:1rem;border-radius:12px;margin-top:1rem}
.note{color:#94a3b8;font-size:.8rem;margin-top:1.5rem;line-height:1.5}.ok{color:#86efac}.err{color:#fecaca;background:#7f1d1d66;border:1px solid #ef444466;border-radius:10px;padding:.75rem;margin-top:1rem;text-align:left;word-break:break-word}
</style></head><body>
<div class="card">
<h1>🍨 Goloso — WhatsApp Bot</h1>
<div class="status">● ${state.status.toUpperCase()}</div>
${state.phone ? `<div class="phone">Número: +${escapeHtml(state.phone)}</div>` : ""}
${state.detail ? `<p class="note">${escapeHtml(state.detail)}</p>` : ""}
${state.qrDataUrl ? `<img src="${state.qrDataUrl}" alt="QR">` : ""}
${state.status === "qr" ? `<p class="note">Abre WhatsApp Business → menú → Dispositivos vinculados → Vincular un dispositivo, y escanea este código.</p>` : ""}
${state.status === "connected" ? `<p class="note">Todo funcionando. Puedes cerrar esta ventana. El bot corre en segundo plano.</p>` : ""}
${state.status === "disconnected" ? `<p class="note">Intentando reconectar automáticamente…</p>` : ""}
${state.status === "connecting" && !state.qrDataUrl ? `<p class="note">Si pasan más de 60 segundos, revisa que el PC tenga internet y que WhatsApp Web no esté bloqueado por antivirus/firewall.</p>` : ""}
${state.lastPushAt ? `<p class="note ok">Panel POS sincronizado.</p>` : ""}
${state.lastOutboundPollAt ? `<p class="note ok">Cola de reportes revisada: ${escapeHtml(new Date(state.lastOutboundPollAt).toLocaleTimeString())}${state.lastOutboundCount ? ` · ${state.lastOutboundCount} pendiente(s)` : ""}</p>` : ""}
${state.lastError ? `<div class="err"><b>Aviso de conexión.</b><br>${escapeHtml(state.lastError)}</div>` : ""}
${state.lastPushError ? `<div class="err"><b>No se pudo sincronizar con el POS.</b><br>${escapeHtml(state.lastPushError)}<br><br>Revisa que el token sea el de la sede seleccionada y que la app esté publicada.</div>` : ""}
${state.lastOutboundError ? `<div class="err"><b>No se pudo procesar la cola de reportes.</b><br>${escapeHtml(state.lastOutboundError)}</div>` : ""}
<p class="note">Este panel se actualiza solo cada 5s.<br>Config y bienvenidas se editan desde el POS.</p>
</div></body></html>`;
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(html);
      return;
    }
    if (req.url === "/status.json") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ status: state.status, phone: state.phone, detail: state.detail, lastError: state.lastError, lastPushAt: state.lastPushAt, lastPushError: state.lastPushError, hasQr: Boolean(state.qr), port: activeLocalPort }));
      return;
    }
    res.writeHead(404); res.end();
  });
  server.on("error", (error) => {
    const message = `Panel local no disponible: ${error?.message || String(error)}`;
    state.lastError = message;
    logger.warn({ err: message }, "local ui error ignored");
    console.warn(`\n⚠️ ${message}\nEl bot seguirá funcionando sin panel local.\n`);
  });
  listenOnAvailablePort(server, REQUESTED_LOCAL_PORT, LOCAL_PORT_SCAN_LIMIT);
}

function listenOnAvailablePort(server, port, remainingAttempts) {
  const onError = (error) => {
    server.off("listening", onListening);
    if (error?.code === "EADDRINUSE" && remainingAttempts > 0) {
      const nextPort = port + 1;
      console.warn(`\n⚠️ El puerto ${port} ya está ocupado. Probando puerto ${nextPort}...\n`);
      logger.warn({ port, nextPort }, "local ui port busy; trying next port");
      const nextServer = http.createServer(server.listeners("request")[0]);
      nextServer.on("error", (fallbackError) => server.emit("error", fallbackError));
      setTimeout(() => listenOnAvailablePort(nextServer, nextPort, remainingAttempts - 1), 250);
      return;
    }
    const message = `No se pudo abrir el panel local en el puerto ${port}: ${error?.message || String(error)}`;
    state.lastError = message;
    logger.warn({ err: message }, "local ui listen failed");
    console.warn(`\n⚠️ ${message}\nEl bot seguirá funcionando sin panel local.\n`);
  };
  const onListening = () => {
    server.off("error", onError);
    activeLocalPort = port;
    console.log(`\n✅ Panel local: http://localhost:${activeLocalPort}\n`);
  };
  server.once("error", onError);
  server.once("listening", onListening);
  server.listen(port);
}

async function main() {
  console.log(`\n🍨 Goloso WhatsApp Bot`);
  console.log(`   Versión : ${BOT_VERSION}`);
  console.log(`   API POS : ${config.apiUrl}`);
  console.log(`   Token   : ${config.token.slice(0, 6)}…${config.token.slice(-4)}`);
  startLocalUI();
  setInterval(pushStatus, HEARTBEAT_MS);
  setInterval(pollOutbound, OUTBOUND_POLL_MS);
  void pushStatus();
  await startSocket().catch((e) => {
    logger.error(e);
    state.status = "error";
    state.lastError = String(e);
    pushStatus();
  });
}

main();
