#!/usr/bin/env bash
set -Eeuo pipefail

BOT_VERSION="8.20.5"
CANONICAL_API_URL="https://golosoheladeria.lovable.app"
PRIMARY_DOWNLOAD_URL="https://golosoheladeria.lovable.app/downloads/golosito-v8.20.5.zip"
FALLBACK_DOWNLOAD_URL="https://golosoheladeria.vercel.app/downloads/golosito-v8.20.5.zip"
DOWNLOAD_URL="${GOLOSO_BOT_ZIP_URL:-${PRIMARY_DOWNLOAD_URL}}"
TARGET_DIR="${1:-$(pwd)}"
PM2_NAME="${2:-${PM2_NAME:-}}"

if [[ -z "${TARGET_DIR}" ]]; then
  echo "[ERROR] Debes indicar la carpeta del bot. Ejemplo: bash update-linux.sh /opt/goloso/sede2 goloso-parque" >&2
  exit 1
fi

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "[ERROR] Falta instalar '$1' en este servidor." >&2
    exit 1
  fi
}

need_cmd node
need_cmd npm
need_cmd pm2
need_cmd curl
need_cmd unzip

if [[ -z "${1:-}" && ! -f "${TARGET_DIR}/config.json" ]]; then
  detected="$(pm2 jlist 2>/dev/null | node - <<'NODE'
const fs = require('fs');
const path = require('path');
let list = [];
try { list = JSON.parse(fs.readFileSync(0, 'utf8') || '[]'); } catch {}
const candidates = [];
for (const p of list) {
  const name = String(p.name || '');
  const cwd = p.pm2_env?.pm_cwd || p.pm2_env?.PWD || '';
  const script = p.pm2_env?.pm_exec_path || '';
  const dir = cwd || (script ? path.dirname(script) : '');
  if (!dir) continue;
  const cfg = path.join(dir, 'config.json');
  const srv = path.join(dir, 'server.js');
  if (!fs.existsSync(cfg) || !fs.existsSync(srv)) continue;
  let score = 0;
  if (/goloso|whatsapp|bot|santa|parque|sede/i.test(name)) score += 4;
  if (/goloso|whatsapp|bot|santa|parque|sede/i.test(dir)) score += 3;
  try {
    const cfgJson = JSON.parse(fs.readFileSync(cfg, 'utf8'));
    if (cfgJson.token && cfgJson.apiUrl) score += 5;
  } catch {}
  try {
    const server = fs.readFileSync(srv, 'utf8');
    if (/BOT_VERSION|Baileys|whatsapp/i.test(server)) score += 5;
  } catch {}
  candidates.push({ name, dir, score });
}
candidates.sort((a, b) => b.score - a.score || a.dir.localeCompare(b.dir));
const pick = candidates[0];
if (pick && pick.score >= 8) console.log(`${pick.dir}\t${pick.name || 'goloso-bot'}`);
NODE
)"
  if [[ -n "${detected}" ]]; then
    TARGET_DIR="${detected%%$'\t'*}"
    detected_name="${detected#*$'\t'}"
    if [[ -z "${PM2_NAME}" ]]; then PM2_NAME="${detected_name}"; fi
    echo "ℹ️ No se indicó carpeta; se detectó automáticamente por PM2: ${TARGET_DIR} (${PM2_NAME})"
  else
    for dir in \
      /root/goloso-parque /root/goloso-santa \
      /opt/goloso/sede2 /opt/goloso/sede1 \
      /opt/goloso-parque /opt/goloso-santa \
      /root/whatsapp-bot /opt/whatsapp-bot \
      /root/goloso /opt/goloso
    do
      if [[ -f "${dir}/config.json" && -f "${dir}/server.js" ]]; then
        TARGET_DIR="${dir}"
        if [[ -z "${PM2_NAME}" ]]; then
          base="$(basename "${dir}" | tr '[:upper:]' '[:lower:]')"
          if [[ "${base}" == *"sede2"* || "${base}" == *"parque"* ]]; then PM2_NAME="goloso-parque";
          elif [[ "${base}" == *"sede1"* || "${base}" == *"santa"* ]]; then PM2_NAME="goloso-santa";
          else PM2_NAME="goloso-bot"; fi
        fi
        echo "ℹ️ No se indicó carpeta; se detectó automáticamente: ${TARGET_DIR}"
        break
      fi
    done
  fi
fi

if [[ -z "${PM2_NAME}" ]]; then
  base="$(basename "${TARGET_DIR}" | tr '[:upper:]' '[:lower:]')"
  if [[ "${base}" == *"sede2"* || "${base}" == *"parque"* ]]; then
    PM2_NAME="goloso-parque"
  elif [[ "${base}" == *"santa"* ]]; then
    PM2_NAME="goloso-santa"
  else
    PM2_NAME="goloso-bot"
  fi
fi

TARGET_DIR="$(mkdir -p "${TARGET_DIR}" && cd "${TARGET_DIR}" && pwd)"
echo ""
echo "🍨 Goloso WhatsApp Bot — actualización Ubuntu/PM2"
echo "   Versión objetivo : ${BOT_VERSION}"
echo "   Carpeta objetivo : ${TARGET_DIR}"
echo "   Proceso PM2      : ${PM2_NAME}"
echo "   ZIP              : ${DOWNLOAD_URL}"

if [[ ! -f "${TARGET_DIR}/config.json" ]]; then
  echo "[ERROR] No existe config.json en ${TARGET_DIR}. Esa no parece ser la carpeta activa del bot." >&2
  echo "        Revisa con: pm2 describe ${PM2_NAME}" >&2
  exit 2
fi

backup_dir="${TARGET_DIR}/backup-before-update-$(date +%Y%m%d-%H%M%S)"
mkdir -p "${backup_dir}"
cp -f "${TARGET_DIR}/config.json" "${backup_dir}/config.json"
if [[ -d "${TARGET_DIR}/auth_state" ]]; then
  cp -a "${TARGET_DIR}/auth_state" "${backup_dir}/auth_state"
fi

tmp_dir="$(mktemp -d)"
cleanup() { rm -rf "${tmp_dir}"; }
trap cleanup EXIT

echo ""
echo "== Descargando paquete actualizado =="
if ! curl -fL --retry 3 --retry-delay 2 "${DOWNLOAD_URL}" -o "${tmp_dir}/whatsapp-bot.zip"; then
  if [[ "${DOWNLOAD_URL}" != "${FALLBACK_DOWNLOAD_URL}" ]]; then
    echo "⚠️ Descarga principal falló; intentando mirror Vercel…"
    DOWNLOAD_URL="${FALLBACK_DOWNLOAD_URL}"
    curl -fL --retry 3 --retry-delay 2 "${DOWNLOAD_URL}" -o "${tmp_dir}/whatsapp-bot.zip"
  else
    exit 3
  fi
fi
unzip -qo "${tmp_dir}/whatsapp-bot.zip" -d "${tmp_dir}/pkg"

if [[ ! -f "${tmp_dir}/pkg/server.js" ]]; then
  echo "[ERROR] El ZIP descargado no contiene server.js." >&2
  exit 3
fi

downloaded_version="$(grep -Eo 'BOT_VERSION[[:space:]]*=[[:space:]]*"[^"]+"' "${tmp_dir}/pkg/server.js" | head -n1 | sed -E 's/.*"([^"]+)"/\1/')"
if [[ "${downloaded_version}" != "${BOT_VERSION}" ]]; then
  echo "[ERROR] El paquete descargado trae versión ${downloaded_version:-desconocida}, se esperaba ${BOT_VERSION}." >&2
    echo "        URL usada: ${DOWNLOAD_URL}" >&2
    echo "        Puede faltar publicar la app o el CDN aún está sirviendo una versión vieja." >&2
  exit 4
fi

echo ""
echo "== Deteniendo proceso anterior y duplicados de la misma sede =="
pm2_json="${tmp_dir}/pm2.json"
pm2 jlist > "${pm2_json}" 2>/dev/null || echo "[]" > "${pm2_json}"
mapfile -t duplicate_pm2_names < <(GOLOSO_TARGET_DIR="${TARGET_DIR}" GOLOSO_PM2_NAME="${PM2_NAME}" GOLOSO_PM2_JSON="${pm2_json}" node <<'NODE'
const fs = require('fs');
const path = require('path');
const targetDir = process.env.GOLOSO_TARGET_DIR;
const pm2Name = process.env.GOLOSO_PM2_NAME;
const pm2Json = process.env.GOLOSO_PM2_JSON;
let targetToken = '';
try { targetToken = JSON.parse(fs.readFileSync(path.join(targetDir, 'config.json'), 'utf8')).token || ''; } catch {}
let list = [];
try { list = JSON.parse(fs.readFileSync(pm2Json, 'utf8') || '[]'); } catch {}
const names = new Set();
for (const p of list) {
  const name = String(p.name || '');
  const cwd = p.pm2_env?.pm_cwd || p.pm2_env?.PWD || '';
  const script = p.pm2_env?.pm_exec_path || '';
  const dir = cwd || (script ? path.dirname(script) : '');
  let token = '';
  try { token = dir ? JSON.parse(fs.readFileSync(path.join(dir, 'config.json'), 'utf8')).token || '' : ''; } catch {}
  if (name === pm2Name || (targetToken && token && token === targetToken)) names.add(name || String(p.pm_id));
}
for (const name of names) console.log(name);
NODE
)
for old_name in "${duplicate_pm2_names[@]:-}"; do
  [[ -n "${old_name}" ]] && pm2 delete "${old_name}" >/dev/null 2>&1 || true
done
pm2 stop "${PM2_NAME}" >/dev/null 2>&1 || true

echo ""
echo "== Copiando archivos sin tocar config.json ni auth_state =="
for file in \
  server.js \
  setup.js \
  package.json \
  package-lock.json \
  README.md \
  update-linux.sh \
  start-hidden.vbs \
  install-windows.bat \
  update-windows.bat \
  update-windows.ps1 \
  update-windows.js \
  ACTUALIZAR-SIN-QR.bat \
  SOLUCION-SIN-SABER-CARPETA.bat \
  uninstall-windows.bat
do
  if [[ -f "${tmp_dir}/pkg/${file}" ]]; then
    cp -f "${tmp_dir}/pkg/${file}" "${TARGET_DIR}/${file}"
  fi
done
chmod +x "${TARGET_DIR}/update-linux.sh" || true

echo ""
echo "== Corrigiendo API POS a dominio con Gemini directo =="
GOLOSO_TARGET_DIR="${TARGET_DIR}" GOLOSO_CANONICAL_API_URL="${CANONICAL_API_URL}" node - <<'NODE'
const fs = require('fs');
const path = require('path');
const targetDir = process.env.GOLOSO_TARGET_DIR;
const canonical = process.env.GOLOSO_CANONICAL_API_URL || 'https://golosoheladeria.lovable.app';
if (!targetDir) {
  throw new Error('GOLOSO_TARGET_DIR no definido');
}
const cfgPath = path.join(targetDir, 'config.json');
const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
cfg.apiUrl = canonical;
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));
console.log(`apiUrl=${canonical}`);
NODE

echo ""
echo "== Instalando dependencias =="
cd "${TARGET_DIR}"
npm install --omit=dev --no-audit --no-fund
node --check server.js

if ! grep -q "BOT_VERSION = \"${BOT_VERSION}\"" "${TARGET_DIR}/server.js"; then
  echo "[ERROR] server.js no quedó en versión ${BOT_VERSION}." >&2
  exit 5
fi

echo ""
echo "== Reiniciando PM2 desde la carpeta correcta =="
pm2 delete "${PM2_NAME}" >/dev/null 2>&1 || true
pm2 start "${TARGET_DIR}/server.js" --name "${PM2_NAME}" --cwd "${TARGET_DIR}" --update-env
pm2 save >/dev/null 2>&1 || true

echo ""
echo "== Verificación =="
sleep 2
pm2 logs "${PM2_NAME}" --lines 25 --nostream || true

status_json=""
for port in 8791 8790 8792 8793; do
  if status_json="$(curl -fsS "http://localhost:${port}/status.json" 2>/dev/null)"; then
    echo ""
    echo "Panel local: http://localhost:${port}/status.json"
    echo "${status_json}"
    break
  fi
done

echo ""
echo "== Instalando auto-actualización diaria (cron 4:00 AM) =="
cron_marker="# goloso-auto-update ${PM2_NAME}"
cron_line="0 4 * * * curl -fsSL https://golosoheladeria.lovable.app/downloads/update-linux.sh | bash -s ${TARGET_DIR} ${PM2_NAME} >> /var/log/goloso-${PM2_NAME}-update.log 2>&1 ${cron_marker}"
( crontab -l 2>/dev/null | grep -v "${cron_marker}" ; echo "${cron_line}" ) | crontab -
echo "Cron instalado: se actualizará automáticamente cada día a las 4:00 AM"

echo ""
echo "✅ Actualización completa. Debe verse: Versión : ${BOT_VERSION}"
echo "   Si PM2 vuelve a mostrar una versión vieja, ejecuta: pm2 describe ${PM2_NAME}"
